﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace semestralka
{
    public class Triangle
    {
        public static bool Zostrojitelny3s(double a, double b, double c)
        {
            return (a + b > c) && (a + c > b) && (b + c > a);
        }
        public static bool Zostrojitelny2s1u(double a, double b,double angle)
        {
            double ca = Strana(a, b, angle);
            

            if (a <= 0 || b <= 0 || angle <= 0 || angle >= 180 || !Zostrojitelny3s(a,b,ca))
            {
                return false;
            }
            else return true;
        }


        public static double Uhol(double a, double b, double c)
        {
            if (a <= 0 || b <= 0 || c <= 0)
            {
                return 0;
            }
            return Math.Acos((a * a + b * b - c * c) / (2 * a * b)) * (180 / Math.PI);
        }
        public static double Alfa(double a, double b, double c)
        {
            return Uhol(b, c, a);
        }

        public static double Beta(double a, double b, double c)
        {
            return Uhol(a, c, b);
        }

        public static double Gama(double a, double b, double c)
        {
            return Uhol(a, b, c);
        }

        //a*a = b*b + c*c - 2*b*c*cos(alfa)
        //2*b*c*cos(alfa) - b*b + a*a = c*c
        //c*c = a*a - b*b + 2*b*c*cos(alfa)
        public static double Strana(double str1, double str2, double uhol)
        {
            if (str1 <= 0 || str2 <= 0 || uhol <= 0 || uhol >= 180)
            {
                return 0;
            }
            return Math.Sqrt(str1 * str1 + str2 * str2 - 2 * str1 * str2 * Math.Cos(uhol * Math.PI / 180));
        }
        /*
        //a*a = b*b + c*c - 2*b*c*cos(alfa)
        public static double uAlfa(double b, double c, double angle)
        {
            return Strana(b, c, angle);
        }

        //b*b = a*a + c*c - 2*a*c*cos(beta)
        public static double uBeta(double a, double c, double angle)
        {
            return Strana(a, c, angle);
        }

        //c*c = a*a + b*b - 2*a*b*cos(gama)
        public static double uGama(double a, double b, double angle)
        {
            return Strana(a, b, angle);
        }*/


        public static string TypTroj(double a, double b, double c)
        {
            if (a == b && b == c)
            {
                return "Rovnostranný";
            }
            else if (a == b || a == c || b == c)
            {
                return "Rovnoramenný";
            }
            else if (a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a)
            {
                return "Pravouhlý";
            }
            else
            {
                return "Všeobecný";
            }
        }

        public static double GetObvod(double a, double b, double c)
        {
            return a + b + c;
        }

        public static double GetObsah(double a, double b, double c)
        {
            //heronov vzorec 
            double s = GetObvod(a, b, c) / 2;
            return Math.Sqrt(s * (s - a) * (s - b) * (s - c));
        }

        public static void SaveContent(string path,string content)
        { 
            try
            { 
                File.WriteAllText(path, content);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Chyba pri ukladaní súboru: {ex.Message}");
            }
        }


    }
}
