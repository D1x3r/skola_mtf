﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace semestralka
{
    
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]

        /*
         * Vytvorte program, ktorý zo zadaných údajov trojuholníka
         * (možné kombinácie sú: dve dĺžky strán trojuholníka (a, b alebo c) 
         * a jeden jeho ľubovoľný uhol (alfa, beta alebo gama),
         * alebo zadané všetky tri dĺžky strán trojuholníka) zistí, 
         * či je zadaný trojuholník zostrojiteľný. Ak je zostrojiteľný, 
         * tak zistí o aký typ trojuholníka ide (pravouhlý, rovnostranný, rovnoramenný...) 
         * a vypočíta jeho obvod a obsah. 
         * Výsledok (zadané hodnoty, typ trojuholníka, obvod a obsah) 
         * budú zapísané do zvoleného textového súboru. 
         * Aplikácia bude obsahovať okno v ktorom sa budú archivovať všetky vykonané výpočty. 
         * Program bude vytvorený ako Win aplikácia. Program by mal vhodným spôsobom 
         * zobrazovať dosiahnutý výsledok. Program by mal obsahovať základné ošetrenie 
         * (vstupné údaje, práca so súbormi...) pomocou odchytávania výnimiek. 
         * Zadanie je možné vypracovať vo vývojovom prostredí SharpDevelop alebo MS Visual Studio. 
         * Odovzdáva sa celý projekt z vývojového prostredia skomprimovaný pomocou 
         * programu WinZip, 7Zip, prípadne WinRar.
         * */






        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
