﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace semestralka
{


    public partial class Form1 : Form
    {
        private string history_content = "";
        private int count = 0;

        private double a = 0;
        private double b = 0;
        private double c = 0;
        private double uhol = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label5.Visible = true;
            label6.Visible = false;
            label7.Visible = false;
            a = 0;
            b = 0;
            c = 0;
            uhol = 0;

            bool Strany3 = !string.IsNullOrWhiteSpace(textBox1.Text) &&
                            !string.IsNullOrWhiteSpace(textBox2.Text) &&
                            !string.IsNullOrWhiteSpace(textBox3.Text);

            bool Strany2Uhol1 = (!string.IsNullOrWhiteSpace(textBox1.Text) &&
                                !string.IsNullOrWhiteSpace(textBox2.Text) &&
                                !string.IsNullOrWhiteSpace(textBox4.Text)) ||

                                (!string.IsNullOrWhiteSpace(textBox1.Text) &&
                                !string.IsNullOrWhiteSpace(textBox3.Text) &&
                                !string.IsNullOrWhiteSpace(textBox4.Text)) ||

                                (!string.IsNullOrWhiteSpace(textBox2.Text) &&
                                !string.IsNullOrWhiteSpace(textBox3.Text) &&
                                !string.IsNullOrWhiteSpace(textBox4.Text));

            if (!Strany3 && !Strany2Uhol1)
            {
                label5.Text = "Zadajte buď tri strany, alebo dve strany a jeden uhol!";
                label5.Visible = true;
                return;
            }

            if (!string.IsNullOrWhiteSpace(textBox1.Text))
            {
                a = double.Parse(textBox1.Text);
            }
            if (!string.IsNullOrWhiteSpace(textBox2.Text))
            {
                b = double.Parse(textBox2.Text);
            }
            if (!string.IsNullOrWhiteSpace(textBox3.Text))
            {
                c = double.Parse(textBox3.Text);
            }
            if (!string.IsNullOrWhiteSpace(textBox4.Text))
            {
                uhol = double.Parse(textBox4.Text);
                if (uhol < 0 || uhol > 180)
                {
                    label5.Text = "Uhol musí byť medzi 0 a 180 stupňami!";
                    label5.Visible = true;
                    return;
                }
            }

            if (Strany3)
            {
                if (Triangle.Zostrojitelny3s(a, b, c))
                {
                    switch (comboBox1.SelectedIndex)
                    {
                        case 0:
                            uhol = Triangle.Alfa(a, b, c);
                            break;
                        case 1:
                            uhol = Triangle.Beta(a, b, c);
                            break;
                        case 2:
                            uhol = Triangle.Gama(a, b, c);
                            break;
                    }
                    textBox4.Text = uhol.ToString("F2");
                    label5.Text = $"Trojuholník je zostrojiteľný a je {Triangle.TypTroj(a, b, c)}";
                    label6.Text = $"Obvod trojuholnika je: {Triangle.GetObvod(a, b, c):F2}";
                    label7.Text = $"Obsah trojuholnika je: {Triangle.GetObsah(a, b, c):F2}";

                    label5.Visible = true;
                    label6.Visible = true;
                    label7.Visible = true;

                    textBox5.Text += $"{++count}. a={a} b={b} c={c} uhol({comboBox1.Text})={uhol:F2}°\r\n" +
                        $"{Triangle.Zostrojitelny3s(a, b, c)}\t" +
                        $"{Triangle.TypTroj(a, b, c)}\t" +
                        $"{Triangle.GetObvod(a, b, c):F2}\t" +
                        $"{Triangle.GetObsah(a, b, c):F2}\r\n\r\n";
                }
                else
                {
                    label5.Text = "Trojuholník nie je zostrojiteľný! Zadajte iné hodnoty.";
                    label5.Visible = true;

                    textBox5.Text += $"{++count}. a={a} b={b} c={c}\t" +
                        $"{Triangle.Zostrojitelny3s(a, b, c)}\r\n";
                }
            }
            else if (Strany2Uhol1)
            {
                double pomocna = 0;
                double pomocna2 = 0;
                if (a == 0)
                {
                    pomocna = b;
                    pomocna2 = c;
                }
                if (b == 0)
                {
                    pomocna = a;
                    pomocna2 = c;
                }
                if (c == 0)
                {
                    pomocna = a;
                    pomocna2 = b;
                }

                if (Triangle.Zostrojitelny2s1u(pomocna, pomocna2, uhol))
                {
                    switch (comboBox1.SelectedIndex)
                    {
                    case 0://alfa
                        if (a == 0) a = Triangle.Strana(b, c, uhol);
                        if (b == 0) b = Triangle.Strana(a, c, uhol); 
                        if (c == 0) c = Triangle.Strana(a, b, uhol); 
                        break;
                    case 1: // Beta
                        if (a == 0) a = Triangle.Strana(b, c, uhol); 
                        if (b == 0) b = Triangle.Strana(a, c, uhol);
                        if (c == 0) c = Triangle.Strana(a, b, uhol); 
                        break;
                    case 2: // Gama
                        if (a == 0) a = Triangle.Strana(b, c, uhol); 
                        if (b == 0) b = Triangle.Strana(a, c, uhol); 
                        if (c == 0) c = Triangle.Strana(a, b, uhol); 
                        break;
                    default:
                        label5.Text = "Vyberte platny uhol";
                        label5.Visible = true;
                        return;
                    }
                    label5.Text = $"Trojuholník je zostrojiteľný a je {Triangle.TypTroj(a, b, c)}";
                    label6.Text = $"Obvod trojuholnika je: {Triangle.GetObvod(a, b, c):F2}";
                    label7.Text = $"Obsah trojuholnika je: {Triangle.GetObsah(a, b, c):F2}";
                    label5.Visible = true;
                    label6.Visible = true;
                    label7.Visible = true;
                    textBox5.Text += $"{++count}. a={a:F2} b={b:F2} c={c:F2} uhol({comboBox1.Text})={uhol:F2}°\r\n" +
                        $"{Triangle.Zostrojitelny2s1u(a, b, uhol)}\t" +
                        $"{Triangle.TypTroj(a, b, c)}\t" +
                        $"{Triangle.GetObvod(a, b, c):F2}\t" +
                        $"{Triangle.GetObsah(a, b, c):F2}\r\n\r\n";
                }
                else
                {
                    label5.Text = "Trojuholník nie je zostrojiteľný! Zadajte iné hodnoty.";
                    label5.Visible = true;
                    textBox5.Text += $"{++count}. a={a} b={b} uhol({comboBox1.Text})={uhol:F2}°\t" +
                        $"{Triangle.Zostrojitelny2s1u(a, b, uhol)}\r\n";
                }
            }

            Console.WriteLine($"{a} {b} {c} {uhol}");
        }

        private void uložiťToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                saveFileDialog.Title = "Ulož súbor";
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;
                    try
                    {
                        File.WriteAllText(filePath, textBox5.Text);
                        this.Text = Path.GetFileName(filePath);
                        MessageBox.Show("Súbor bol uložený", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Chyba pri ukladaní súboru: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
